# Customer Credit Risk — Data Preprocessing & Feature Engineering

## Project contents
- `Customer_Credit_Risk_Preprocessing.ipynb`: complete, executable end-to-end notebook.
- `data/customer_credit_risk.csv`: synthetic customer-level source dataset (1,500 rows).
- `data/customer_metadata.json`: supplementary customer metadata.
- `data/repayment_history_source.csv`: source used to demonstrate SQL acquisition.
- `outputs/`: generated charts and processed CSV files after running the notebook.
- `requirements.txt`: Python dependencies.

## Run
1. Extract the ZIP.
2. Open a terminal in this folder.
3. Install: `pip install -r requirements.txt`
4. Start: `jupyter notebook`
5. Open `Customer_Credit_Risk_Preprocessing.ipynb` and select **Run All**.

The notebook is self-contained and uses a local in-memory SQLite database plus an offline dummy API payload, so no API key or internet access is required.

## Important
All data is synthetic and intended only for academic demonstration. It is not suitable for real lending decisions.
